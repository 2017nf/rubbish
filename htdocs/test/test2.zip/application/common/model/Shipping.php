<?php
namespace app\common\model;
use think\Model;
use think\Db;
class Shipping extends Model
{
	
}