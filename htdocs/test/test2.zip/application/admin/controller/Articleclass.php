<?php
namespace app\admin\controller;
use think\Db;
use think\Controller;
class Articleclass extends Common
{
	
}
