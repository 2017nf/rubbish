<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:59:"E:\php\xampp\htdocs/application/game\view\myhome\index.html";i:1501202670;}*/ ?>
<!DOCTYPE>
<html>
<head>
	<title></title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge，chrome=1">
    <meta name="description" content="不超过150个字符"/>
    <meta name="keywords" content="">
    <meta name="format-detection" content="telephone=no">
    <meta name="robots" content="index,follow"/>
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta name="HandheldFriendly" content="true">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <!--[if lt IE 9]>      
	    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        *{margin:0;padding:0;}
    </style>
</head>
<body style="background: #0E0226;overflow: hidden;">
    <div style="width: 100%;padding:0.5rem 0rem 0.7rem;background: #291B4C;line-height: 0.8rem;">
        <img src="<?php echo $memberinfo['photo']; ?>" style="width: 4rem;float: left;margin-left: 0.5rem;"><span style="margin-left:0.5rem;line-height: 1.5rem;color: white;font-size: 1.1rem;"><?php echo $memberinfo['nickname']; ?></span><br/><br/><img src="__STATIC__/game/img/roomCard.png" style="width: 1.2rem;margin-left: 0.5rem;vertical-align: middle;"><span style="display: inline-block;padding-right: 1rem;padding-left:0.3rem;height: 1.3rem;border-top-right-radius: 0.5rem;border-bottom-right-radius:0.5rem;background: #000;font-size: 0.8rem;color:white;line-height: 1.3rem;"><?php echo $memberinfo['cards']; ?></span>
    </div>
    <a href="<?php echo url('Redbag/index'); ?>" style="text-decoration: none">
        <p style="margin-top: 1rem;background: #291B4C;height:2.7rem;font-size:0.9rem;color:white;letter-spacing: 0.05rem;padding-left:0.5rem;line-height: 2.7rem;">
        <img src="__STATIC__/game/img/hongbao.jpg" style="width: 1.7rem;vertical-align: middle;margin-right: 0.5rem;">发送房卡红包
        <img src="__STATIC__/game/img/next.jpg" style="width: 0.8rem;margin-top:0.8rem;vertical-align: middle;float: right;margin-right: 0.5rem;">
        </p>
    </a>
   <a href="<?php echo url('Redbag/history'); ?>" style="text-decoration: none">
       <p style="margin-top: 1rem;background: #291B4C;height:2.7rem;font-size:0.9rem;color:white;letter-spacing: 0.05rem;padding-left:0.5rem;line-height: 2.7rem;">
           <img src="__STATIC__/game/img/record.jpg" style="width: 1.4rem;margin-left:0.2rem;margin-right: 0.5rem;vertical-align: middle;">点击查看红包记录
           <img src="__STATIC__/game/img/next.jpg" style="width: 0.8rem;margin-top:0.8rem;vertical-align: middle;float: right;margin-right: 0.5rem;">
       </p>
   </a>
</body>
</html>